using UnityEngine.InputSystem;
using UnityEngine;

public class CameraFollow : MonoBehaviour
{
    public Transform target;
    public Vector3 offset;
    public float mouseSpeed = 5f;
    public Transform pivot;

    void Start()
    {
        offset = target.position - Camera.main.transform.position;

        pivot.position = target.position;
        pivot.parent = target;
    }

    void Update()
    {
        Camera.main.transform.position = target.position - offset;
        Vector2 mouseDelta = Mouse.current.delta.ReadValue();

        float horizontal = mouseDelta.x * mouseSpeed * Time.deltaTime;
        target.Rotate(0, 10f * horizontal, 0);

        float vertical = -mouseDelta.y * mouseSpeed * Time.deltaTime;
        pivot.Rotate(10f * vertical, 0, 0);

        if (pivot.eulerAngles.x > 60f && pivot.eulerAngles.x < 180f)
            pivot.rotation = Quaternion.Euler(60f, pivot.eulerAngles.y, 0);
        if (pivot.eulerAngles.x > 180f && pivot.eulerAngles.x < 330f)
            pivot.rotation = Quaternion.Euler(330f, pivot.eulerAngles.y, 0);

        float desiredYAngle = target.eulerAngles.y;
        float desiredXAngle = pivot.eulerAngles.x;

        Quaternion rotation = Quaternion.Euler(desiredXAngle, desiredYAngle, 0);
        transform.position = target.position - (rotation * offset);

        if (transform.position.y < target.position.y)
            transform.position = new Vector3(transform.position.x, target.position.y - 0.5f, transform.position.z);

        transform.LookAt(target);
    }
}
