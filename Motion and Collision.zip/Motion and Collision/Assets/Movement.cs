using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

public class Movement : MonoBehaviour
{
    public CharacterController controller;
    public int speed = 2;
    private Vector3 startPosition;

    void Start()
    {
        controller = GetComponent<CharacterController>();
        startPosition = transform.position; 
    }

    void Update()
    {
        if (Keyboard.current.wKey.isPressed)
            controller.Move(transform.forward * Time.deltaTime * speed);

        if (Keyboard.current.aKey.isPressed)
            controller.Move(-transform.right * Time.deltaTime * speed);

        if (Keyboard.current.sKey.isPressed)
            controller.Move(-transform.forward * Time.deltaTime * speed);

        if (Keyboard.current.dKey.isPressed)
            controller.Move(transform.right * Time.deltaTime * speed);
    }

    public void OnControllerColliderHit(ControllerColliderHit hit)
    {
        if (hit.collider.tag == "Barrel")
        {
            Debug.Log("Hit");
            transform.position = startPosition; 
        }
    }
}
